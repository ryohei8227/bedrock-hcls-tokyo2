"""
Test package for bedrock-ez-search
"""
