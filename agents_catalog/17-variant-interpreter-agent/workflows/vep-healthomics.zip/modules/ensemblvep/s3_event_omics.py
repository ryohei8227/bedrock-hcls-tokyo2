import boto3
import json
import os
import urllib.parse

def lambda_handler(event, context):
    """
    Lambda function to detect S3 file uploads and trigger a HealthOmics workflow.
    
    Args:
        event (dict): S3 event data
        context (obj): Lambda context
    
    Returns:
        dict: Response containing workflow run details
    """
    try:
        # Extract S3 bucket and file information from the event
        s3_event = event['Records'][0]['s3']
        bucket_name = s3_event['bucket']['name']
        object_key = urllib.parse.unquote_plus(s3_event['object']['key'])
        
        # Check if the uploaded file is in the expected prefix
        target_prefix = os.environ.get('TARGET_PREFIX', 'data/')
        if not object_key.startswith(target_prefix):
            print(f"File {object_key} not in target prefix {target_prefix}. Ignoring.")
            return {
                'statusCode': 200,
                'body': 'File not in target prefix, no workflow triggered'
            }
        
        # Get HealthOmics workflow parameters from environment variables
        workflow_id = os.environ.get('HEALTHOMICS_WORKFLOW_ID')
        role_arn = os.environ.get('HEALTHOMICS_ROLE_ARN')
        
        if not workflow_id or not role_arn:
            raise ValueError("Required environment variables not set: HEALTHOMICS_WORKFLOW_ID, HEALTHOMICS_ROLE_ARN")
        
        # Construct the S3 URI for the new file
        s3_uri = f"s3://{bucket_name}/{object_key}"
        
        # Prepare the input parameters for the workflow
        # Adjust these parameters based on your specific workflow requirements
        workflow_params = {
            "inputFile": s3_uri,
            "sampleId": object_key.split('/')[-1].split('.')[0]
        }
        
        # Create HealthOmics client
        omics_client = boto3.client('omics')
        
        # Start the workflow run
        response = omics_client.start_run(
            workflowId=workflow_id,
            roleArn=role_arn,
            name=f"Process-{workflow_params['sampleId']}",
            parameters=workflow_params,
            priority=1,
            storageCapacity=1200
        )
        
        print(f"Started HealthOmics workflow run: {response['id']}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Successfully triggered workflow',
                'workflowRunId': response['id'],
                'inputFile': s3_uri
            })
        }
    
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'message': f"Error triggering workflow: {str(e)}"
            })
        }